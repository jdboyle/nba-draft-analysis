from pprint import pprint
import json
import csv
from bs4 import BeautifulSoup
import requests


draftsdict = {}
resp = requests.get(f"https://basketball.realgm.com/nba/draft/past-drafts/2004")
soup = BeautifulSoup(resp.text, "html.parser")
rows = soup.find_all("tr")
draftlist = []
for i in range(1,30):
    pick = rows[i]
    pickstats = pick.find_all("td")

    pickdict = {"pick":pickstats[0].text, "name":pickstats[1].text, "pickteam":pickstats[2].text, \
    "draft_trade":pickstats[3].text, "position":pickstats[4].text, "height":pickstats[5].text, \
    "weight":pickstats[6].text, "age":pickstats[7].text, "years_played":pickstats[8].text, \
    "pre-draft_team":pickstats[9].text, "class":pickstats[10].text}

    draftlist.append(pickdict)

pick30 = rows[32]           #must do 2004 separately because due to a salary violation the thirtieth pick was part of the second round
pickstats = pick.find_all("td")

pickdict = {"pick":pickstats[0].text, "name":pickstats[1].text, "pickteam":pickstats[2].text, \
"draft_trade":pickstats[3].text, "position":pickstats[4].text, "height":pickstats[5].text, \
"weight":pickstats[6].text, "age":pickstats[7].text, "years_played":pickstats[8].text, \
"pre-draft_team":pickstats[9].text, "class":pickstats[10].text}

draftlist.append(pickdict)

draftsdict[str(2004)] = draftlist
print("2004 finished")


for year in range(2005,2020):
    resp = requests.get(f"https://basketball.realgm.com/nba/draft/past-drafts/{year}")
    soup = BeautifulSoup(resp.text, "html.parser")
    rows = soup.find_all("tr")
    draftlist = []
    for i in range(1,31):
        pick = rows[i]
        pickstats = pick.find_all("td")

        pickdict = {"pick":pickstats[0].text, "name":pickstats[1].text, "pickteam":pickstats[2].text, \
        "draft_trade":pickstats[3].text, "position":pickstats[4].text, "height":pickstats[5].text, \
        "weight":pickstats[6].text, "age":pickstats[7].text, "years_played":pickstats[8].text, \
        "pre-draft_team":pickstats[9].text, "class":pickstats[10].text}

        draftlist.append(pickdict)

    draftsdict[str(year)] = draftlist
    print(year, "finished")

json.dump(draftsdict, open("../Data Collection and Cleaning/Clean Data/drafts.json", "w"))




#To-do list to clean draft data:
#Change 2004 and 2005 players' class who were drafted out of HS to "HS" -- done
#Change intl players' class to "INTL" -- done
#Remove "*" from each players' class -- done
#Fix team for draft-day trade (maybe then change trade column to a boolean) -- done
#could add 1 to years' played but most likely doing manipulation/analysis on data prior to this season so we have postseason

adict = json.load(open("../Data Collection and Cleaning/Clean Data/drafts.json", "r"))

#for year in range(2004,2020):
#    for pick in range(0,30):
#        print(adict[str(year)][pick]["class"])

for year in range(2004,2020): #removes "*" from each players' class
    for pick in range(0,30):
        if "Sr" in adict[str(year)][pick]["class"]:
            adict[str(year)][pick]["class"] = "Sr"
        elif "Jr" in adict[str(year)][pick]["class"]:
            adict[str(year)][pick]["class"] = "Jr"
        elif "So" in adict[str(year)][pick]["class"]:
            adict[str(year)][pick]["class"] = "So"
        elif "Fr" in adict[str(year)][pick]["class"]:
            adict[str(year)][pick]["class"] = "Fr"

#changing class of HS players to "HS" (list of HS players from wikipedia)
adict["2004"][0]["class"] = "HS"
adict["2004"][3]["class"] = "HS"
adict["2004"][11]["class"] = "HS"
adict["2004"][12]["class"] = "HS"
adict["2004"][14]["class"] = "HS"
adict["2004"][16]["class"] = "HS"
adict["2004"][17]["class"] = "HS"
adict["2004"][18]["class"] = "HS"
adict["2005"][5]["class"] = "HS"
adict["2005"][9]["class"] = "HS"
adict["2005"][17]["class"] = "HS"

#changing class of intl players to "INTL"
usaclasses = ["Fr","So","Jr","Sr","HS"]
for year in range(2004,2020):
    for pick in range(0,30):
        if not adict[str(year)][pick]["class"] in usaclasses:
            adict[str(year)][pick]["class"] = "INTL"

#changing draft day trade team
for year in range(2004,2020):
    for pick in range(0,30):
        if adict[str(year)][pick]["draft_trade"] != "":
            adict[str(year)][pick]["pickteam"] = adict[str(year)][pick]["draft_trade"][len(adict[str(year)][pick]["draft_trade"])-3:]

json.dump(adict, open("../Data Collection and Cleaning/Clean Data/cleandrafts.json", "w"))




with open("../Data Collection and Cleaning/Raw Data/raw1.csv", "r", encoding = "utf8") as fin:
    dictReader = csv.DictReader(fin)
    listofdicts = [dict(line) for line in dictReader]


namelist = []
for year in range(2004,2020):
    for pick in range(0,30):
        namelist.append(adict[str(year)][pick]["name"])

newlistofdicts = []
for i in range(0,len(listofdicts)-1):
    if listofdicts[i]["player_name"] in namelist:
        newlistofdicts.append(listofdicts[i])

for player in newlistofdicts:
    del player["player_id"]
    del player["war_total"]
    del player["war_reg_season"]
    del player["war_playoffs"]
    del player["pace_impact"]

for player in newlistofdicts:
    for year in range(2004,2020):
        for pick in range(0,30):
            if player["player_name"] == adict[str(year)][pick]["name"]:
                player["pick"] = pick + 1
                player["draft_year"] = year
                player["position"] = adict[str(year)][pick]["position"]
                player["draft_class"] = adict[str(year)][pick]["class"]
                player["draft_team"] = adict[str(year)][pick]["pickteam"]
    player["career_year"] = int(player["season"]) - player["draft_year"]
    if player["career_year"] < 0:
        newlistofdicts.remove(player)


with open("../Data Collection and Cleaning/Clean Data/cleanRAPTOR.csv", "w") as fout:
    dw = csv.DictWriter(fout, fieldnames = newlistofdicts[0].keys())
    dw.writeheader()
    dw.writerows(newlistofdicts)
