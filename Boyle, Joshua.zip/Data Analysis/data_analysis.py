import csv
import json
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns


dfraptor = pd.read_csv("../Data Collection and Cleaning/Clean Data/cleanRAPTOR.csv")


"""decide which ones should be raptor and which should be raptor/num of players"""

#Q1: Which NBA draft picks offer the most first-year value, playoff value, and career value?
def question1(db):
    """In the draft, different teams target players for different reasons. Some
    teams have several star players and are ready to compete for a championship,
    so they just need someone who will be ready to fill minutes, especially in
    the regular season. Some teams want to find another high-level player who can
    push them into contention in the postseason, and some teams want to build
    long-term by finding players who could have great careers even if they aren't
    as good their first few years. Some teams may even want to trade away their pick
    if they can get more value than its worth or steal a better one from a team
    unsure of its true value."""
    print("Question 1: Which NBA draft picks offer the most first-year value, playoff value, and career value?")
    firstyear = dfraptor[dfraptor["career_year"] == 1]
    firstyear = firstyear.groupby("pick")["raptor_total"].sum()
    firstyear = firstyear.sort_values(ascending = False)
    print(firstyear.head())
    firstyear = firstyear.reset_index()
    print(f"Players selected with picks {int(firstyear.iloc[0,0])}, {int(firstyear.iloc[1,0])}, and {int(firstyear.iloc[2,0])} offer the most value in their first year.")

    playoffvalue = dfraptor[dfraptor["season_type"] == "PO"]
    playoffvalue = playoffvalue.groupby("pick")["raptor_total"].sum()
    playoffvalue = playoffvalue.sort_values(ascending = False)
    print(playoffvalue.head())
    playoffvalue = playoffvalue.reset_index()
    print(f"Players selected with picks {int(playoffvalue.iloc[0,0])}, {int(playoffvalue.iloc[1,0])}, and {int(playoffvalue.iloc[2,0])} offer the most career playoff value.")

    career = dfraptor.groupby("pick")["raptor_total"].sum()
    career = career.sort_values(ascending = False)
    print(career.head())
    career = career.reset_index()
    print(f"Players selected with picks {int(career.iloc[0,0])}, {int(career.iloc[1,0])}, and {int(career.iloc[2,0])} offer the most career value.")
    career.to_csv("../Data Analysis/Data Summaries/careerRAPTOR.csv", index = True)



#Q2: Players drafted at what points in their basketball careers are the most impactful, and how long do they last?
def question2(db):
    """In general, players who are drafted as freshmen out of college are thought
    of as having the most potential, but they also often fail because of their youth
    and inexperience. Older players don't have high ceilings, but they generally
    perform well since they are drafted as known quantities to fill as specific role.
    International players fill a whole different niche as they are young yet have
    been playing older, adult men for years already in slower, yet still very skilled leagues."""
    print("Question 2: Players drafted at what points in their basketball careers are the most impactful, and how long do they last?")
    draft_class = dfraptor.groupby("draft_class").aggregate({"raptor_total":"mean","career_year":"mean"})
    draft_class = draft_class.sort_values(by = "raptor_total",ascending = False)
    print(draft_class)
    draft_class = draft_class.reset_index()
    class1 = draft_class.iloc[0,0]
    if class1 == "Fr":
        class1 = "Freshman"
    if class1 == "So":
        class1 = "Sophomore"
    if class1 == "Jr":
        class1 = "Junior"
    if class1 == "Sr":
        class1 = "Senior"
    if class1 == "HS":
        class1 = "High School Senior"
    if class1 == "INTL":
        class1 = "International Professional"
    class2 = draft_class.iloc[1,0]
    if class2 == "Fr":
        class2 = "Freshman"
    if class2 == "So":
        class2 = "Sophomore"
    if class2 == "Jr":
        class2 = "Junior"
    if class2 == "Sr":
        class2 = "Senior"
    if class2 == "HS":
        class2 = "High School Senior"
    if class2 == "INTL":
        class2 = "International Professional"
    draft_class = draft_class.sort_values(by = "career_year",ascending = False)
    class3 = draft_class.iloc[0,0]
    if class3 == "Fr":
        class3 = "Freshman"
    if class3 == "So":
        class3 = "Sophomore"
    if class3 == "Jr":
        class3 = "Junior"
    if class3 == "Sr":
        class3 = "Senior"
    if class3 == "HS":
        class3 = "High School Senior"
    if class3 == "INTL":
        class3 = "International Professional"
    class4 = draft_class.iloc[1,0]
    if class4 == "Fr":
        class4 = "Freshman"
    if class4 == "So":
        class4 = "Sophomore"
    if class4 == "Jr":
        class4 = "Junior"
    if class4 == "Sr":
        class4 = "Senior"
    if class4 == "HS":
        class4 = "High School Senior"
    if class4 == "INTL":
        class4 = "International Professional"
    print(f"Players drafted as a {class1} and {class2} have the most career impact, but players drafted as a {class3} and {class4} have the longest average careers.")


#Q3: Which teams have gotten the most value from picking in the first round and retaining those players since 2004??
def question3(db):
    """The results of this question could be skewed by how many picks each team
    has had and where those picks fell, but there have been few teams that were
    either dominant or terrible for the entire past sixteen years, so it evens
    out somewhat. Seeing which teams have gotten the most value can help those teams
    struggling. Maybe historically bad teams are that way because they draft poorly
    even though they would have higher draft picks due to their poor records. They
    could learn something by studying the teams who have had more draft success with
    worse/less picks."""
    print("Question 3: Which teams have gotten the most value from picking in the first round and retaining those players since 2004?")
    with_first_team = dfraptor[dfraptor["team"] == dfraptor["draft_team"]]
    teams = with_first_team.groupby("team")["raptor_total"].sum()
    teams = teams.sort_values(ascending = False)
    print(teams.head())
    teams = teams.reset_index()
    print(f"The five teams to get the most value from drafting and retaining players since 2004 are {teams.iloc[0,0]}, {teams.iloc[1,0]}, {teams.iloc[2,0]}, {teams.iloc[3,0]}, and {teams.iloc[4,0]}.")
    teams.to_csv("../Data Analysis/Data Summaries/team_draft_success.csv", index = True)


#Q4: When do players reach their peak, and are young players better than experienced veterans?
def question4(db):
    """In the typical NBA career arc, players are not great to start, get better,
    peak, then decline and retire. Finding a more exact age that players typically
    peak could be useful, but that is not the endgame here. Contending teams typically
    try to fill out their roster with veteran players who know the game and have
    polished skills but are past their primes phsyically. Do vets really provide
    more than talented, athletic, young players?"""
    print("Question 4: When do players reach their peak, and are young players better than experienced veterans?")
    combineseason = dfraptor.groupby(["player_name","career_year"])["raptor_total"].sum()
    combineseason = combineseason.reset_index()
    ages = combineseason.groupby("career_year").aggregate({"raptor_total":"mean","player_name":"count"})
    print(ages)
    ages = ages.reset_index()
    if ages.iloc[-1,2]+ages.iloc[-2,2]+ages.iloc[-3,2] < ages.iloc[0,2]+ages.iloc[1,2]+ages.iloc[2,2]:
        amount = "more"
    else:
        amount = "less"
    if ages.iloc[-1,1]+ages.iloc[-2,1]+ages.iloc[-3,1] < ages.iloc[0,1]+ages.iloc[1,1]+ages.iloc[2,1]:
        rap = "more"
    else:
        rap = "less"
    ages = ages.sort_values(by = "raptor_total", ascending = False)
    print(f"A typical player's best year is their {int(ages.iloc[0,0])}th. Young players, on average, provide {rap} value than older players. Keep in mind, however, that there are {amount} younger players to choose from than veterans.")

#Q5: Which teams made the better choice in recent star trades?
def question5(db):
    """Because of the way contracts are designed now, star players have more power
    than ever before to force a trade to a team they would prefer. Typically, these
    players net their teams a couple of decent young players and several draft picks.
    Do several picks, which may or may not turn into good players, really outweigh
    the benefits of having a guaranteed star? I will compare the expected future
    values of the picks and players included in three of the biggest trades from
    the past few years to see whether or not teams are typically receiving good
    value for their star commodities and making the right move by trading them.
    We will get the future value of each player
    by multiplying their PREDATOR score, their predictive RAPTOR for the next season,
    by a conservative five remaining seasons (star players tend to play until they
    are older than other players barring injury)."""
    print("Question 5: Which teams made the better choice in recent star trades?")
    #pg, ad, kawhi
    #First we must copy in the dataframe for career impact from question1:
    career_value = dfraptor.groupby("pick")["raptor_total"].sum()
    print("Trade 1: 2017: Chicago trades Jimmy Butler and the 16th pick in the draft for Zach Lavine and the 7th pick in that year's draft.")
    players2017 = dfraptor[dfraptor["season"] == 2017]
    butler = players2017[players2017["player_name"] == "Jimmy Butler"]
    bpredator = butler["predator_total"].sum() * 5
    zach = players2017[players2017["player_name"] == "Zach LaVine"]
    zpredator = zach["predator_total"].sum() * 5
    predator16 = career_value[16]
    predator7 = career_value[7]
    print(f"Chicago made the right move by trading away Jimmy Butler: {bpredator + predator16 < zpredator + predator7}.")
    print("Trade 2: 2019: New Orleans trades Anthony Davis for Lonzo Ball, Brandon Ingram, Josh Hart, the 4th pick in that year's draft, and two future first round picks.")
    players2019 = dfraptor[dfraptor["season"] == 2019]
    ad = players2019[players2019["player_name"] == "Anthony Davis"]
    apredator = ad["predator_total"].sum() * 5
    lonzo = players2019[players2019["player_name"] == "Lonzo Ball"]
    lpredator = lonzo["predator_total"].sum() * 5
    bi = players2019[players2019["player_name"] == "Brandon Ingram"]
    bpredator = bi["predator_total"].sum() * 5
    josh = players2019[players2019["player_name"] == "Josh Hart"]
    jpredator = josh["predator_total"].sum() * 5
    predator4 = career_value[4]
    predatorpick = career_value.mean()
    print(f"New Orleans made the right move by trading away Anthony Davis: {apredator < lpredator + bpredator + jpredator + predator4 + 2 * predatorpick}")
    print("""Trade 3: 2019: Oklahoma City trades Paul George and Russell Westbrook for Chris Paul, Shai Gilgeous-Alexander, Danilo Gallinari, three future first round picks, and two first round picks protected 1-4. Note: The pick protection means that if the pick in that certain year falls in spots 5-30, Oklahoma City gets it, otherwise they get it not matter what the next year.""")
    pg = players2019[players2019["player_name"] == "Paul George"]
    ppredator = pg["predator_total"].sum() * 5
    russ = players2019[players2019["player_name"] == "Russell Westbrook"]
    rpredator = russ["predator_total"].sum() * 5
    cp = players2019[players2019["player_name"] == "Chris Paul"]
    cpredator = cp["predator_total"].sum() * 5
    sga = players2019[players2019["player_name"] == "Shai Gilgeous-Alexander"]
    spredator = sga["predator_total"].sum() * 5
    gallo = players2019[players2019["player_name"] == "Danilo Gallinari"]
    dpredator = gallo["predator_total"].sum() * 5
    predatorprotected = career_value[5:30].mean()
    predatorprotected = (predatorprotected + predatorpick)/2
    print(f"Oklahoma City made the right move by trading away Paul George and Russell Westbrook: {ppredator + rpredator < cpredator + spredator + dpredator + 3 * predatorpick + 2 * predatorprotected}")




#functions:
question1(dfraptor)
question2(dfraptor)
question3(dfraptor)
question4(dfraptor)
question5(dfraptor)



#Three Visuals:
#Scatter plot of picks vs. reg season and postseason value
def visual1(db):
    playoffvalue = dfraptor[dfraptor["season_type"] == "PO"]
    playoffvalue = playoffvalue.groupby("pick")["raptor_total"].sum()
    playoffvalue = playoffvalue.reset_index()
    regseasonvalue = dfraptor[dfraptor["season_type"] == "RS"]
    regseasonvalue = regseasonvalue.groupby("pick")["raptor_total"].sum()
    regseasonvalue = regseasonvalue.reset_index()
    plt.figure(figsize=(15,5))
    ax = sns.lineplot(x = range(1, 31), y = 'raptor_total', color = sns.xkcd_rgb['red'], data = regseasonvalue, label = "Regular Season")
    ax = sns.lineplot(x = range(1, 31), y = 'raptor_total', color = sns.xkcd_rgb['blue'], data = playoffvalue, label = "Playoffs")
    plt.xticks(range(1, 31))
    ax.set_xlabel('Draft Pick')
    ax.set_ylabel('Total RAPTOR')
    ax.set_title('RAPTOR Impact for First Round Picks')
    ax.legend()
    plt.savefig("../Data Analysis/Data Summaries/vis1raptor_line.png")


#histogram of career raptor value
def visual2(db):
    plt.clf()
    careerraptor = dfraptor.groupby("player_name")["raptor_total"].sum()
    careerraptor = careerraptor.reset_index()
    sns.set(color_codes = True)
    ay = sns.distplot(careerraptor["raptor_total"], kde = False)
    ay.set_xlabel("RAPTOR")
    ay.set_ylabel("Number of Players")
    ay.set_title("Career RAPTOR Total")
    plt.savefig("../Data Analysis/Data Summaries/vis2raptor_hist.png")

#amount of years played per pick bar chart
def visual3(db):
    careerlength = dfraptor.groupby(["player_name", "pick"])["career_year"].max()
    careerlength = careerlength.reset_index()
    careerlength = careerlength.groupby("pick")["career_year"].mean()
    careerlength = careerlength.reset_index()
    plt.figure(figsize=(15,5))
    ax = sns.barplot(x = "pick", y = "career_year", data = careerlength)
    ax.set_xlabel("Draft Pick")
    ax.set_ylabel("Years in League")
    ax.set_title("Career Length for First Round Picks")
    plt.savefig("../Data Analysis/Data Summaries/vis3careerlength.png")
    careerlength.to_csv("../Data Analysis/Data Summaries/career_length.csv", index = True)



#visual functions:
visual1(dfraptor)
visual2(dfraptor)
visual3(dfraptor)
